#!/bin/bash
# Run outreach directly without going through the interactive menu.
# Usage: bash scripts/run_outreach.sh
cd "$(dirname "$0")/.."
python src/main.py << 'INPUT'
4
INPUT

import os
import io
import re
import csv
import time
import glob
import json
import shlex
import zipfile
import requests
import subprocess
import platform

from cache import *
from status import *
from config import *

try:
    from twilio.rest import Client as TwilioClient
except ImportError:
    TwilioClient = None

try:
    import phonenumbers
except ImportError:
    phonenumbers = None


class Outreach:
    """
    Reaches out to local businesses with NO website via SMS using Twilio.
    Skips already-contacted numbers across runs using a local cache.
    """

    def __init__(self) -> None:
        self.go_installed = os.system("go version") == 0
        self.niche = get_google_maps_scraper_niche()
        self.twilio_sid = get_twilio_account_sid()
        self.twilio_token = get_twilio_auth_token()
        self.twilio_from = get_twilio_from_number()
        self.sms_template = get_sms_message_template()
        self._contacted_cache_path = os.path.join(get_cache_path(), "outreach_contacted.json")
        self._load_contacted_cache()

    def _load_contacted_cache(self) -> None:
        if os.path.exists(self._contacted_cache_path):
            with open(self._contacted_cache_path, "r") as f:
                data = json.load(f)
                self._contacted = set(data.get("contacted", []))
        else:
            self._contacted = set()

    def _save_contacted_cache(self) -> None:
        with open(self._contacted_cache_path, "w") as f:
            json.dump({"contacted": list(self._contacted)}, f, indent=2)

    def _find_scraper_dir(self) -> str:
        candidates = sorted(glob.glob("google-maps-scraper-*"))
        for candidate in candidates:
            if os.path.isdir(candidate) and os.path.exists(os.path.join(candidate, "go.mod")):
                return candidate
        return ""

    def is_go_installed(self) -> bool:
        try:
            subprocess.call(["go", "version"])
            return True
        except Exception:
            return False

    def unzip_file(self, zip_link: str) -> None:
        if self._find_scraper_dir():
            info("=> Scraper already unzipped. Skipping.")
            return
        r = requests.get(zip_link)
        z = zipfile.ZipFile(io.BytesIO(r.content))
        for member in z.namelist():
            if ".." in member or member.startswith("/"):
                warning(f"Skipping suspicious path: {member}")
                continue
            z.extract(member)

    def build_scraper(self) -> None:
        binary_name = "google-maps-scraper.exe" if platform.system() == "Windows" else "google-maps-scraper"
        if os.path.exists(binary_name):
            info("=> Scraper already built. Skipping.")
            return
        scraper_dir = self._find_scraper_dir()
        if not scraper_dir:
            raise FileNotFoundError("Could not locate extracted google-maps-scraper directory.")
        subprocess.run(["go", "mod", "download"], cwd=scraper_dir, check=True)
        subprocess.run(["go", "build"], cwd=scraper_dir, check=True)
        built_binary = os.path.join(scraper_dir, binary_name)
        if not os.path.exists(built_binary):
            raise FileNotFoundError(f"Expected built binary at: {built_binary}")
        os.replace(built_binary, binary_name)

    def run_scraper(self, args: str, timeout=300) -> None:
        info(" => Running Google Maps scraper...")
        binary_name = "google-maps-scraper.exe" if platform.system() == "Windows" else "google-maps-scraper"
        command = [os.path.join(os.getcwd(), binary_name)] + shlex.split(args)
        try:
            result = subprocess.run(command, timeout=float(timeout))
            if result.returncode == 0:
                success("=> Scraper finished successfully.")
            else:
                warning("=> Scraper finished with an error.")
        except subprocess.TimeoutExpired:
            warning("=> Scraper timed out.")
        except Exception as e:
            error(f"Scraper error: {e}")

    def normalize_phone(self, raw: str) -> str:
        """Normalizes any phone string to E.164 format. Returns '' if unparseable."""
        if not phonenumbers:
            error("phonenumbers library not installed. Run: pip install phonenumbers")
            return ""
        if not raw or not raw.strip():
            return ""
        try:
            parsed = phonenumbers.parse(raw.strip(), "US")
            if phonenumbers.is_valid_number(parsed):
                return phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.E164)
        except Exception:
            pass
        return ""

    def send_sms(self, to_number: str, company_name: str) -> bool:
        """Sends an intro SMS via Twilio. Returns True on success."""
        if not TwilioClient:
            error("twilio not installed. Run: pip install twilio")
            return False
        if not self.twilio_sid or not self.twilio_token or not self.twilio_from:
            error("Twilio credentials missing in config.json.")
            return False
        body = self.sms_template.replace("{{COMPANY_NAME}}", company_name)
        try:
            client = TwilioClient(self.twilio_sid, self.twilio_token)
            message = client.messages.create(body=body, from_=self.twilio_from, to=to_number)
            success(f" => SMS sent to {to_number} (SID: {message.sid})")
            return True
        except Exception as e:
            warning(f" => SMS failed for {to_number}: {e}")
            return False

    def parse_rows(self, file_path: str) -> list:
        """
        Reads the scraper CSV. Uses header names if present (robust),
        otherwise falls back to google-maps-scraper v0.9.7 column order.
        Returns list of dicts with keys: name, website, phone.
        """
        rows = []
        with open(file_path, "r", errors="ignore", newline="") as f:
            reader = csv.reader(f)
            all_rows = list(reader)

        if not all_rows:
            return rows

        first_lower = [c.strip().lower() for c in all_rows[0]]
        has_headers = any(k in first_lower for k in ["title", "name", "phone", "website"])

        if has_headers:
            headers = first_lower
            data = all_rows[1:]
            def get(row, *names):
                for name in names:
                    try:
                        idx = headers.index(name)
                        return row[idx].strip() if idx < len(row) else ""
                    except ValueError:
                        continue
                return ""
            for row in data:
                if not any(row):
                    continue
                rows.append({
                    "name":    get(row, "title", "name"),
                    "website": get(row, "website"),
                    "phone":   get(row, "phone"),
                })
        else:
            # Fallback: v0.9.7 order — input_id(0), link(1), title(2),
            # category(3), address(4), open_hours(5), website(6), phone(7)
            for row in all_rows[1:]:
                if not any(row):
                    continue
                def safe(i): return row[i].strip() if i < len(row) else ""
                rows.append({
                    "name":    safe(2),
                    "website": safe(6),
                    "phone":   safe(7),
                })

        return rows

    def start(self) -> None:
        """
        Full outreach pipeline:
        1. Build scraper if needed
        2. Scrape Google Maps for the configured niche
        3. Filter to businesses with NO website
        4. Normalize phone numbers to E.164
        5. Skip already-contacted numbers
        6. Send intro SMS via Twilio
        7. Persist contacted numbers to cache
        """
        if not self.is_go_installed():
            error("Go is not installed. Get it at https://golang.org/")
            return

        self.unzip_file(get_google_maps_scraper_zip_url())
        self.build_scraper()

        with open("niche.txt", "w") as f:
            f.write(self.niche)

        output_path = get_results_cache_path()
        self.run_scraper(f'-input niche.txt -results "{output_path}"', timeout=get_scraper_timeout())

        if os.path.exists("niche.txt"):
            os.remove("niche.txt")

        if not os.path.exists(output_path):
            error(f"Scraper output not found at {output_path}.")
            return

        all_rows = self.parse_rows(output_path)
        success(f" => Scraped {len(all_rows)} total businesses.")

        targets = [r for r in all_rows if not r["website"].strip()]
        success(f" => {len(targets)} have no website — texting these.")

        sent = skipped_dup = skipped_no_phone = 0

        for biz in targets:
            name = biz["name"] or "there"
            raw = biz["phone"]

            if not raw:
                skipped_no_phone += 1
                continue

            e164 = self.normalize_phone(raw)
            if not e164:
                warning(f" => Can't normalize '{raw}' for {name}. Skipping.")
                skipped_no_phone += 1
                continue

            if e164 in self._contacted:
                skipped_dup += 1
                if get_verbose():
                    info(f" => Already contacted {name} ({e164}). Skipping.")
                continue

            ok = self.send_sms(e164, name)
            if ok:
                self._contacted.add(e164)
                self._save_contacted_cache()
                sent += 1
                time.sleep(1)

        success(f"\n => Outreach complete.")
        success(f"    Texts sent:        {sent}")
        info(f"    Already contacted: {skipped_dup}")
        info(f"    No phone number:   {skipped_no_phone}")

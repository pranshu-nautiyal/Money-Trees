import sys

from status import *
from cache import get_accounts
from config import get_verbose, get_affiliate_links
from classes.Tts import TTS
from classes.Twitter import Twitter
from classes.YouTube import YouTube
from classes.AFM import AffiliateMarketing
from llm_provider import select_model


def run_twitter(account_id: str) -> None:
    """Posts a plain tweet for the given account."""
    accounts = get_accounts("twitter")
    for acc in accounts:
        if acc["id"] == account_id:
            if get_verbose():
                info("Initializing Twitter (plain tweet)...")
            twitter = Twitter(acc["id"], acc["nickname"], acc["firefox_profile"], acc["topic"])
            twitter.post()
            if get_verbose():
                success("Done posting tweet.")
            return
    error(f"Twitter account {account_id} not found.")


def run_affiliate(account_id: str) -> None:
    """
    Posts an affiliate tweet for the given account.
    Cycles through affiliate_links in config — picks one based on current hour
    so different links get promoted across the day.
    """
    links = get_affiliate_links()
    if not links:
        warning("No affiliate_links configured in config.json. Falling back to plain tweet.")
        run_twitter(account_id)
        return

    accounts = get_accounts("twitter")
    for acc in accounts:
        if acc["id"] == account_id:
            from datetime import datetime
            link = links[datetime.now().hour % len(links)]
            if get_verbose():
                info(f"Initializing Affiliate Marketing with link: {link}")
            try:
                afm = AffiliateMarketing(
                    link,
                    acc["firefox_profile"],
                    acc["id"],
                    acc["nickname"],
                    acc["topic"],
                )
                afm.generate_pitch()
                afm.share_pitch("twitter")
                if get_verbose():
                    success("Done posting affiliate tweet.")
            except Exception as e:
                warning(f"Affiliate post failed ({e}). Falling back to plain tweet.")
                run_twitter(account_id)
            return
    error(f"Twitter account {account_id} not found.")


def run_youtube(account_id: str) -> None:
    """Generates and uploads a YouTube Short for the given account."""
    tts = TTS()
    accounts = get_accounts("youtube")
    for acc in accounts:
        if acc["id"] == account_id:
            if get_verbose():
                info("Initializing YouTube...")
            youtube = YouTube(
                acc["id"],
                acc["nickname"],
                acc["firefox_profile"],
                acc["niche"],
                acc["language"],
            )
            youtube.generate_video(tts)
            youtube.upload_video()
            if get_verbose():
                success("Uploaded Short.")
            return
    error(f"YouTube account {account_id} not found.")


def main() -> None:
    """
    Entry point called by the scheduler in main.py.

    Args (sys.argv):
        1: purpose — "twitter", "twitter_affiliate", or "youtube"
        2: account_uuid
        3: ollama model name
    """
    if len(sys.argv) < 4:
        error("Usage: cron.py <purpose> <account_uuid> <model>")
        sys.exit(1)

    purpose = str(sys.argv[1])
    account_id = str(sys.argv[2])
    model = str(sys.argv[3])

    select_model(model)

    if purpose == "twitter":
        run_twitter(account_id)
    elif purpose == "twitter_affiliate":
        run_affiliate(account_id)
    elif purpose == "youtube":
        run_youtube(account_id)
    else:
        error(f"Unknown purpose '{purpose}'. Expected: twitter, twitter_affiliate, youtube.")
        sys.exit(1)


if __name__ == "__main__":
    main()

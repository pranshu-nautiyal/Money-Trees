import schedule
import subprocess
import os
import sys

from art import *
from cache import *
from utils import *
from config import *
from status import *
from uuid import uuid4
from constants import *
from classes.Tts import TTS
from termcolor import colored
from classes.Twitter import Twitter
from classes.YouTube import YouTube
from prettytable import PrettyTable
from classes.Outreach import Outreach
from classes.AFM import AffiliateMarketing
from llm_provider import list_models, select_model, get_active_model


# ---------------------------------------------------------------------------
# Schedule
# ---------------------------------------------------------------------------
# YouTube:  12:00am, 4:00am, 8:00am, 4:00pm, 8:00pm  (5x/day)
# Twitter:  1:00am, 5:00am, 9:00am, 12:00pm, 5:00pm, 9:00pm  (6x/day)
#   - Affiliate tweets at: 9:00am and 5:00pm
#   - Plain tweets at all other times
# Each YouTube run is followed by a Twitter run 1 hour later — no overlap.
# ---------------------------------------------------------------------------

YOUTUBE_TIMES  = ["00:00", "04:00", "08:00", "16:00", "20:00"]
TWITTER_PLAIN_TIMES     = ["01:00", "05:00", "12:00", "21:00"]
TWITTER_AFFILIATE_TIMES = ["09:00", "17:00"]


def setup_youtube_cron(account_id: str) -> None:
    cron_path = os.path.join(ROOT_DIR, "src", "cron.py")
    model = get_active_model()

    def job():
        subprocess.run(["python", cron_path, "youtube", account_id, model])

    for t in YOUTUBE_TIMES:
        schedule.every().day.at(t).do(job)

    success(f"YouTube CRON set — uploads at: {', '.join(YOUTUBE_TIMES)}")


def setup_twitter_cron(account_id: str) -> None:
    cron_path = os.path.join(ROOT_DIR, "src", "cron.py")
    model = get_active_model()

    def plain_job():
        subprocess.run(["python", cron_path, "twitter", account_id, model])

    def affiliate_job():
        subprocess.run(["python", cron_path, "twitter_affiliate", account_id, model])

    for t in TWITTER_PLAIN_TIMES:
        schedule.every().day.at(t).do(plain_job)

    for t in TWITTER_AFFILIATE_TIMES:
        schedule.every().day.at(t).do(affiliate_job)

    success(
        f"Twitter CRON set — plain tweets at: {', '.join(TWITTER_PLAIN_TIMES)} | "
        f"affiliate tweets at: {', '.join(TWITTER_AFFILIATE_TIMES)}"
    )


# ---------------------------------------------------------------------------
# Main menu
# ---------------------------------------------------------------------------

def main():
    valid_input = False
    while not valid_input:
        try:
            info("\n============ OPTIONS ============", False)
            for idx, option in enumerate(OPTIONS):
                print(colored(f" {idx + 1}. {option}", "cyan"))
            info("=================================\n", False)
            user_input = input("Select an option: ").strip()
            if user_input == "":
                raise ValueError("Empty input is not allowed.")
            user_input = int(user_input)
            valid_input = True
        except ValueError as e:
            print(f"Invalid input: {e}")

    # ------------------------------------------------------------------ 1. YouTube
    if user_input == 1:
        info("Starting YouTube Shorts Automater...")
        cached_accounts = get_accounts("youtube")

        if len(cached_accounts) == 0:
            warning("No accounts found. Create one now?")
            if question("Yes/No: ").lower() == "yes":
                generated_uuid = str(uuid4())
                success(f" => Generated ID: {generated_uuid}")
                nickname  = question(" => Nickname for this account: ")
                fp_profile = question(" => Path to Firefox profile: ")
                niche     = question(" => Channel niche: ")
                language  = question(" => Language: ")
                add_account("youtube", {
                    "id": generated_uuid,
                    "nickname": nickname,
                    "firefox_profile": fp_profile,
                    "niche": niche,
                    "language": language,
                    "videos": [],
                })
                success("Account created!")
        else:
            table = PrettyTable()
            table.field_names = ["ID", "UUID", "Nickname", "Niche"]
            for acc in cached_accounts:
                table.add_row([
                    cached_accounts.index(acc) + 1,
                    colored(acc["id"], "cyan"),
                    colored(acc["nickname"], "blue"),
                    colored(acc["niche"], "green"),
                ])
            print(table)
            info("Type 'd' to delete an account.", False)
            user_input = question("Select account (or 'd' to delete): ").strip()

            if user_input.lower() == "d":
                delete_input = question("Account number to delete: ").strip()
                for acc in cached_accounts:
                    if str(cached_accounts.index(acc) + 1) == delete_input:
                        confirm = question(f"Delete '{acc['nickname']}'? (Yes/No): ").strip().lower()
                        if confirm == "yes":
                            remove_account("youtube", acc["id"])
                            success("Account removed.")
                        else:
                            warning("Cancelled.")
                        return

            selected = None
            for acc in cached_accounts:
                if str(cached_accounts.index(acc) + 1) == user_input:
                    selected = acc

            if selected is None:
                error("Invalid selection.")
                main()
                return

            youtube = YouTube(
                selected["id"], selected["nickname"],
                selected["firefox_profile"], selected["niche"], selected["language"]
            )

            while True:
                rem_temp_files()
                info("\n============ YOUTUBE OPTIONS ============", False)
                for idx, opt in enumerate(YOUTUBE_OPTIONS):
                    print(colored(f" {idx + 1}. {opt}", "cyan"))
                info("=========================================\n", False)

                choice = int(question("Select an option: "))
                tts = TTS()

                if choice == 1:
                    # Generate and auto-upload — no confirmation prompt
                    youtube.generate_video(tts)
                    youtube.upload_video()
                elif choice == 2:
                    videos = youtube.get_videos()
                    if videos:
                        t = PrettyTable()
                        t.field_names = ["ID", "Date", "Title"]
                        for v in videos:
                            t.add_row([
                                videos.index(v) + 1,
                                colored(v["date"], "blue"),
                                colored(v["title"][:60] + "...", "green"),
                            ])
                        print(t)
                    else:
                        warning("No videos yet.")
                elif choice == 3:
                    setup_youtube_cron(selected["id"])
                    info("Scheduler running. Keep this terminal open.")
                    while True:
                        schedule.run_pending()
                        import time; time.sleep(30)
                elif choice == 4:
                    break

    # ------------------------------------------------------------------ 2. Twitter
    elif user_input == 2:
        info("Starting Twitter Bot...")
        cached_accounts = get_accounts("twitter")

        if len(cached_accounts) == 0:
            warning("No accounts found. Create one now?")
            if question("Yes/No: ").lower() == "yes":
                generated_uuid = str(uuid4())
                success(f" => Generated ID: {generated_uuid}")
                nickname   = question(" => Nickname: ")
                fp_profile = question(" => Path to Firefox profile: ")
                topic      = question(" => Topic: ")
                add_account("twitter", {
                    "id": generated_uuid,
                    "nickname": nickname,
                    "firefox_profile": fp_profile,
                    "topic": topic,
                    "posts": [],
                })
                success("Account created!")
        else:
            table = PrettyTable()
            table.field_names = ["ID", "UUID", "Nickname", "Topic"]
            for acc in cached_accounts:
                table.add_row([
                    cached_accounts.index(acc) + 1,
                    colored(acc["id"], "cyan"),
                    colored(acc["nickname"], "blue"),
                    colored(acc["topic"], "green"),
                ])
            print(table)
            info("Type 'd' to delete an account.", False)
            user_input = question("Select account (or 'd' to delete): ").strip()

            if user_input.lower() == "d":
                delete_input = question("Account number to delete: ").strip()
                for acc in cached_accounts:
                    if str(cached_accounts.index(acc) + 1) == delete_input:
                        confirm = question(f"Delete '{acc['nickname']}'? (Yes/No): ").strip().lower()
                        if confirm == "yes":
                            remove_account("twitter", acc["id"])
                            success("Account removed.")
                        else:
                            warning("Cancelled.")
                        return

            selected = None
            for acc in cached_accounts:
                if str(cached_accounts.index(acc) + 1) == user_input:
                    selected = acc

            if selected is None:
                error("Invalid selection.")
                main()
                return

            twitter = Twitter(selected["id"], selected["nickname"], selected["firefox_profile"], selected["topic"])

            while True:
                info("\n============ TWITTER OPTIONS ============", False)
                for idx, opt in enumerate(TWITTER_OPTIONS):
                    print(colored(f" {idx + 1}. {opt}", "cyan"))
                info("=========================================\n", False)

                choice = int(question("Select an option: "))

                if choice == 1:
                    twitter.post()
                elif choice == 2:
                    posts = twitter.get_posts()
                    t = PrettyTable()
                    t.field_names = ["ID", "Date", "Content"]
                    for p in posts:
                        t.add_row([
                            posts.index(p) + 1,
                            colored(p["date"], "blue"),
                            colored(p["content"][:60] + "...", "green"),
                        ])
                    print(t)
                elif choice == 3:
                    setup_twitter_cron(selected["id"])
                    info("Scheduler running. Keep this terminal open.")
                    while True:
                        schedule.run_pending()
                        import time; time.sleep(30)
                elif choice == 4:
                    break

    # ------------------------------------------------------------------ 3. Affiliate Marketing
    elif user_input == 3:
        info("Starting Affiliate Marketing...")
        cached_products = get_products()

        if len(cached_products) == 0:
            warning("No products found. Add one now?")
            if question("Yes/No: ").lower() == "yes":
                affiliate_link  = question(" => Affiliate link: ")
                twitter_uuid    = question(" => Twitter Account UUID: ")
                account = None
                for acc in get_accounts("twitter"):
                    if acc["id"] == twitter_uuid:
                        account = acc
                add_product({"id": str(uuid4()), "affiliate_link": affiliate_link, "twitter_uuid": twitter_uuid})
                afm = AffiliateMarketing(affiliate_link, account["firefox_profile"], account["id"], account["nickname"], account["topic"])
                afm.generate_pitch()
                afm.share_pitch("twitter")
        else:
            table = PrettyTable()
            table.field_names = ["ID", "Affiliate Link", "Twitter Account UUID"]
            for p in cached_products:
                table.add_row([cached_products.index(p) + 1, colored(p["affiliate_link"], "cyan"), colored(p["twitter_uuid"], "blue")])
            print(table)
            user_input = question("Select a product: ")
            selected = None
            for p in cached_products:
                if str(cached_products.index(p) + 1) == user_input:
                    selected = p
            if selected is None:
                error("Invalid selection.")
                main()
                return
            account = None
            for acc in get_accounts("twitter"):
                if acc["id"] == selected["twitter_uuid"]:
                    account = acc
            afm = AffiliateMarketing(selected["affiliate_link"], account["firefox_profile"], account["id"], account["nickname"], account["topic"])
            afm.generate_pitch()
            afm.share_pitch("twitter")

    # ------------------------------------------------------------------ 4. Outreach
    elif user_input == 4:
        info("Starting Outreach...")
        outreach = Outreach()
        outreach.start()

    # ------------------------------------------------------------------ 5. Quit
    elif user_input == 5:
        sys.exit(0)
    else:
        error("Invalid option.")
        main()


if __name__ == "__main__":
    print_banner()

    first_time = get_first_time_running()
    if first_time:
        print(colored("First time running — let's get you set up!", "yellow"))

    assert_folder_structure()
    rem_temp_files()
    fetch_songs()

    configured_model = get_ollama_model()
    if configured_model:
        select_model(configured_model)
        success(f"Using configured model: {configured_model}")
    else:
        try:
            models = list_models()
        except Exception as e:
            error(f"Could not connect to Ollama: {e}")
            sys.exit(1)

        if not models:
            error("No Ollama models found. Run: ollama pull llama3.2:3b")
            sys.exit(1)

        info("\n========== OLLAMA MODELS =========", False)
        for idx, m in enumerate(models):
            print(colored(f" {idx + 1}. {m}", "cyan"))
        info("==================================\n", False)

        model_choice = None
        while model_choice is None:
            raw = input(colored("Select a model: ", "magenta")).strip()
            try:
                idx = int(raw) - 1
                if 0 <= idx < len(models):
                    model_choice = models[idx]
                else:
                    warning("Invalid selection.")
            except ValueError:
                warning("Enter a number.")

        select_model(model_choice)
        success(f"Using model: {model_choice}")

    while True:
        main()
